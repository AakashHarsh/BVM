void main() {
    int a = 5 - 2;
    int b = a > 2;
    int c  = a == b;

}
