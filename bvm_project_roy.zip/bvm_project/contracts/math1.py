# Simple arithmetic smart contract
'''a = 3
b = 5
result_add = a + b

c = 10
d = 2
result_sub = c - d
result_mul = a * c
result_div = c / a'''
# Modulo and comparison examples
'''x = 10
y = 3

mod_result = x % y           # 1
less_than = x < y            # 0 (False)
greater_than = x > y         # 1 (True)
equal_to = x == y            # 0 (False)
is_zero = (x - 10) == 0      # 1 (True)'''

# math_contract.py
x = 10
y = 3
z = 2

# Simple operations
a = x + y
b = x - y

# Nested operations
c = (x + y) % z
d = (x * y) - (z + 5)

# Comparisons with expressions
e = (x + y) > (z * 5)
